public class main
{
        public static void main(String[]args)
        {
                Controlador controlador = new Controlador();
                controlador.eleccion_modelo();
                controlador.menu();
        }
}
