public class Cabeza
{
    private boolean estado= false;

    public Cabeza() {
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
}
