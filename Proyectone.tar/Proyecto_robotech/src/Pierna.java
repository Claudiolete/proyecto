public class Pierna
{
    private boolean estado= false;

    public Pierna() {
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
}
