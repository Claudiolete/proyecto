public class Pista
{
    private int longitud;

    Pista(int longitud)
    {
        this.longitud = longitud;

    }

    public int getLongitud()
    {
        return longitud;
    }

    public void setLongitud(int longitud)
    {
        this.longitud = longitud;
    }
}
