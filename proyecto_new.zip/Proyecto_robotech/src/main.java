public class main
{
        public static void main(String[]args) throws InterruptedException {
                Controlador controlador = new Controlador();
                controlador.eleccionModelo();
                controlador.menu();
                ////distancia recorrida , pista clase aparte
        }
}
