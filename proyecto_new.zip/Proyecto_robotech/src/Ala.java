import java.util.ArrayList;

public class Ala
{
    private boolean estado = false;
    private  int altura;
    private ArrayList<Arma> armas_lasers;

    public Ala()
    {
        armas_lasers = new ArrayList<Arma>();
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public void agregarArma(Arma x)
    {
        this.armas_lasers.add(x);
    }

}
